﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

using Excepciones;

namespace EntidadesAbstractas
{

    public abstract class Persona
    {
        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }

        #region ATRIBUTOS
        private string nombre;
        private string apellido;
        private ENacionalidad nacionalidad;
        private int dni;
        #endregion

        #region PROPIEDADES
        /// <summary>
        /// Devuelve y setea el nombre de la Persona
        /// </summary>
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                this.nombre = this.ValidarNombreApellido(value);
            }
        }

        /// <summary>
        /// Devuelve y setea el apellido de la Persona
        /// </summary>
        public string Apellido
        {
            get
            {
                return this.apellido;
            }
            set
            {
                this.apellido = this.ValidarNombreApellido(value);
            }
        }

        /// <summary>
        /// Devuelve y setea la nacionalidad
        /// </summary>
        public ENacionalidad Nacionalidad
        {
            get
            {
                return this.nacionalidad;
            }
            set
            {
                this.nacionalidad = value;
            }

        }

        /// <summary>
        /// Devuelve y setea el DNI
        /// </summary>
        public int DNI
        {
            get
            {
                return this.dni;
            }
            set
            {
                this.dni = ValidarDni(this.nacionalidad, value);
            }
        }

        /// <summary>
        /// Setea el DNI pasado como string 
        /// </summary>
        public string StringToDni
        {
            set
            {
                this.dni = ValidarDni(this.nacionalidad, value);
            }
        }
        #endregion

        #region CONSTRUCTORES
        /// <summary>
        /// Constructor de persona por defecto
        /// </summary>
        public Persona() : this("", "", default(ENacionalidad))
        {
            this.dni = 0;
        }

        /// <summary>
        /// Constructor de Persona a partir de los datos pasados por parámetro
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad) 
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.nacionalidad = nacionalidad;
        }

        /// <summary>
        /// Constructor de Persona a partir de los datos pasados por parámetro
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad) : 
                        this(nombre, apellido, nacionalidad)
        {
            this.DNI = dni;
        }

        /// <summary>
        /// Constructor de Persona a partir de los datos pasados por parámetro y con el DNI pasado como string
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad):
                        this(nombre,apellido,nacionalidad)
        {
            this.StringToDni = dni;
        }
#endregion

        #region MÉTODOS
        /// <summary>
        /// Retorna los datos de la persona en formato String
        /// </summary>
        /// <returns></returns>
        public virtual string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("NOMBRE COMPLETO: {0} {1} ", this.Nombre, this.Apellido);
            sb.AppendLine("NACIONALIDAD: " + this.Nacionalidad.ToString());
            sb.AppendLine("DNI: " + this.DNI);

            return sb.ToString();
        }


        /// <summary>
        /// Validad el DNi, con dato tipo INT 
        /// </summary>
        /// <param name="nacionalidad"> valor campo _nacionalidad</param>
        /// <param name="dato">valor int para _dni</param>
        /// <returns></returns>
        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            return this.ValidarDni(nacionalidad, dato.ToString());
        }

        /// <summary>
        /// Validad el DNi, con dato tipo STRING 
        /// </summary>
        /// <param name="nacionalidad"> valor campo _nacionalidad</param>
        /// <param name="dato">valor STRING para _dni</param>
        /// <returns></returns>
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int retorno = -1;
            int dni;

            if (dato.Length <= 8 && Int32.TryParse(dato, out dni))
            {
                dni = Int32.Parse(dato);

                switch (nacionalidad)
                {
                    case ENacionalidad.Argentino:
                        if (dni > 0 && dni <= 89999999)
                        {
                            retorno = dni;
                        }
                        else
                        {
                            throw new NacionalidadInvalidaException("\nLa Nacionalidad y DNI, no coinciden.");
                        }
                        break;

                    case ENacionalidad.Extranjero:

                        if (dni >= 90000000 && dni <= 99999999)
                        {
                            retorno = dni;
                        }
                        else
                        {
                            throw new NacionalidadInvalidaException("\nLa Nacionalidad y DNI, no coinciden.");
                        }

                        break;

                    default:
                        break;
                }
            }
            else
            {
                throw new DniInvalidoException("Dni formato incorrecto");
            }

            return retorno;
        }

        /// <summary>
        /// Validad nombre y apellido
        /// </summary>
        /// <param name="dato"> dato string a validar </param>
        /// <returns>valor string</returns>
        private string ValidarNombreApellido(string dato)
        {
            foreach (char temporal in dato)
            {
                if (!(char.IsLetter(temporal)))
                {
                    return "No se pudo cargar.";
                }
            }

            return dato;
        }
        #endregion
    }
}
