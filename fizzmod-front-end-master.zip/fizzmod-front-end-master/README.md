# FIZZMOD

## clase 1

* GIT
1. rebase 
2. revert
3. reset
